# -*- coding: utf-8 -*-

# ----------------------------------------
# About method
CONF_METHOD = {
    "yapi.secret.createSecret"  : "cgi_createSecret",
    "yapi.secret.operateSecret" : "cgi_operateSecret",
    "yapi.secret.remarkSecret"  : "cgi_remarkSecret",
    "yapi.secret.getSecretList" : "cgi_getSecretList",
    "yapi.secret.getSecretKey"  : "cgi_getSecretKey"
}
